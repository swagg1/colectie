This is my loader from Selly, decided to self leak since so many people are already leaking it. Enjoy

# Web Files
For the provided web-file just update the SQL login info and it should work perfectly.

If it does not, your SQL info is incorrect

Along with the provided file, it will need you to make some for it to work.

1. version.txt (Can be placed anywhere in your web files, does not matter)

2. status.txt (Same as above)

For version.txt, anytime you update the loader, update the number in there. Start it at 1000 and work your way up.

There is a string "version" in form1, make sure that corresponds to the current version.

For status.txt, this allows you to lock your cheat at any time. 0 = closed, 1 = open, 2 = matinance, 3 = detected.

Set status to only be "1" by default.

# File Encrypter.exe

Select your dll and set a password for the dll.

Upload your encrypted dll (.dll.des) to your website.

Update the KeyText with the password you set.

# Junk Gen

Update the file paths to match those of where you place the loader at.

Spam "generate" 6-8 times then build. DO NOT do under 5, spamming over does not matter

# Loader Files

Basically just update all the links and such and design... Not too hard
